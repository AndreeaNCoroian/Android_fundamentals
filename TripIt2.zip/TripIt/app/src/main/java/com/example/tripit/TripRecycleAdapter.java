package com.example.tripit;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class TripRecycleAdapter extends RecyclerView.Adapter<TripRecycleAdapter.ViewHolder>{

    private final Context mContext;
    private final LayoutInflater mlayoutInflater;

    public TripRecycleAdapter(Context mContext) {
        this.mContext = mContext;
        mlayoutInflater = LayoutInflater.from(mContext);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = mlayoutInflater.inflate(R.layout.item_trip_list, viewGroup, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }



    public class ViewHolder extends RecyclerView.ViewHolder{

        private final TextView textTrip;
        private final TextView textDestination;


        public ViewHolder(@NonNull View itemView) {

            TextView textTrip = (TextView) itemView.findViewById(R.id.text_trip);
            TextView textDestination = (TextView) itemView.findViewById(R.id.text_destination);

            super(itemView);
        }
    }
}
